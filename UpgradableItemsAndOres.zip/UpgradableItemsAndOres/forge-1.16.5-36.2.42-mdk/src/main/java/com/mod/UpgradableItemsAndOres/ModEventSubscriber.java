package com.mod.UpgradableItemsAndOres; // Ajuste o pacote para onde estão seus arquivos

import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import com.mod.UpgradableItemsAndOres.ModArmorMaterial; // Importe corretamente ModArmorMaterial

@Mod.EventBusSubscriber(modid = UpgradableItemsAndOres.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModEventSubscriber {
    @SubscribeEvent
    public static void onRegisterItems(RegistryEvent.Register<Item> event) {
        event.getRegistry().registerAll(
            new ArmorItem(ModArmorMaterial.CHAINETHARILE, EquipmentSlotType.HEAD, new Item.Properties().tab(ItemGroup.TAB_COMBAT)).setRegistryName(UpgradableItemsAndOres.MOD_ID, "chainetharile_helmet"),
            new ArmorItem(ModArmorMaterial.CHAINETHARILE, EquipmentSlotType.CHEST, new Item.Properties().tab(ItemGroup.TAB_COMBAT)).setRegistryName(UpgradableItemsAndOres.MOD_ID, "chainetharile_chestplate"),
            new ArmorItem(ModArmorMaterial.CHAINETHARILE, EquipmentSlotType.LEGS, new Item.Properties().tab(ItemGroup.TAB_COMBAT)).setRegistryName(UpgradableItemsAndOres.MOD_ID, "chainetharile_leggings"),
            new ArmorItem(ModArmorMaterial.CHAINETHARILE, EquipmentSlotType.FEET, new Item.Properties().tab(ItemGroup.TAB_COMBAT)).setRegistryName(UpgradableItemsAndOres.MOD_ID, "chainetharile_boots"),
            new ArmorItem(ModArmorMaterial.CHAINMOLDEN, EquipmentSlotType.HEAD, new Item.Properties().tab(ItemGroup.TAB_COMBAT)).setRegistryName(UpgradableItemsAndOres.MOD_ID, "chainmolden_helmet"),
            new ArmorItem(ModArmorMaterial.CHAINMOLDEN, EquipmentSlotType.CHEST, new Item.Properties().tab(ItemGroup.TAB_COMBAT)).setRegistryName(UpgradableItemsAndOres.MOD_ID, "chainmolden_chestplate"),
            new ArmorItem(ModArmorMaterial.CHAINMOLDEN, EquipmentSlotType.LEGS, new Item.Properties().tab(ItemGroup.TAB_COMBAT)).setRegistryName(UpgradableItemsAndOres.MOD_ID, "chainmolden_leggings"),
            new ArmorItem(ModArmorMaterial.CHAINMOLDEN, EquipmentSlotType.FEET, new Item.Properties().tab(ItemGroup.TAB_COMBAT)).setRegistryName(UpgradableItemsAndOres.MOD_ID, "chainmolden_boots"),
            new ArmorItem(ModArmorMaterial.CHAINMOND, EquipmentSlotType.HEAD, new Item.Properties().tab(ItemGroup.TAB_COMBAT)).setRegistryName(UpgradableItemsAndOres.MOD_ID, "chainmond_helmet"),
            new ArmorItem(ModArmorMaterial.CHAINMOND, EquipmentSlotType.CHEST, new Item.Properties().tab(ItemGroup.TAB_COMBAT)).setRegistryName(UpgradableItemsAndOres.MOD_ID, "chainmond_chestplate"),
            new ArmorItem(ModArmorMaterial.CHAINMOND, EquipmentSlotType.LEGS, new Item.Properties().tab(ItemGroup.TAB_COMBAT)).setRegistryName(UpgradableItemsAndOres.MOD_ID, "chainmond_leggings"),
            new ArmorItem(ModArmorMaterial.CHAINMOND, EquipmentSlotType.FEET, new Item.Properties().tab(ItemGroup.TAB_COMBAT)).setRegistryName(UpgradableItemsAndOres.MOD_ID, "chainmond_boots"),
            new ArmorItem(ModArmorMaterial.CHINMRON, EquipmentSlotType.HEAD, new Item.Properties().tab(ItemGroup.TAB_COMBAT)).setRegistryName(UpgradableItemsAndOres.MOD_ID, "chinmron_helmet"),
            new ArmorItem(ModArmorMaterial.CHINMRON, EquipmentSlotType.CHEST, new Item.Properties().tab(ItemGroup.TAB_COMBAT)).setRegistryName(UpgradableItemsAndOres.MOD_ID, "chinmron_chestplate"),
            new ArmorItem(ModArmorMaterial.CHINMRON, EquipmentSlotType.LEGS, new Item.Properties().tab(ItemGroup.TAB_COMBAT)).setRegistryName(UpgradableItemsAndOres.MOD_ID, "chinmron_leggings"),
            new ArmorItem(ModArmorMaterial.CHINMRON, EquipmentSlotType.FEET, new Item.Properties().tab(ItemGroup.TAB_COMBAT)).setRegistryName(UpgradableItemsAndOres.MOD_ID, "chinmron_boots")
        );
    }
}

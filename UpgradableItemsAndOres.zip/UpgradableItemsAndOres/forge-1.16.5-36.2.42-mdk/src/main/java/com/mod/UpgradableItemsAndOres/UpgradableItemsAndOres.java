package com.mod.UpgradableItemsAndOres;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLDedicatedServerSetupEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(UpgradableItemsAndOres.MOD_ID)
public class UpgradableItemsAndOres {
    public static final String MOD_ID = "upgradableitemsandores";
    private static final Logger LOGGER = LogManager.getLogger();

    public UpgradableItemsAndOres() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        modEventBus.addListener(this::setup);
        modEventBus.addListener(this::doClientStuff);
        modEventBus.addListener(this::doServerStuff);
    }

    private void setup(final FMLCommonSetupEvent event) {
        LOGGER.info("Setup method registered.");
    }

    private void doClientStuff(final FMLClientSetupEvent event) {
        LOGGER.info("Client setup method registered.");
    }

    private void doServerStuff(final FMLDedicatedServerSetupEvent event) {
        LOGGER.info("Dedicated server setup method registered.");
    }
}

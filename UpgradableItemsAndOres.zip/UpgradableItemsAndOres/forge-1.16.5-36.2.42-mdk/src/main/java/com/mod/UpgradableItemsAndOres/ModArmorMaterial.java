package com.mod.UpgradableItemsAndOres;  // Pacote correto do arquivo ModArmorMaterial.java

import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.item.IArmorMaterial;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.SoundEvents;
import net.minecraft.item.Items;
import net.minecraftforge.common.util.Lazy;

import java.util.function.Supplier;

public enum ModArmorMaterial implements IArmorMaterial {
    CHAINETHARILE("chainetharile", 25, new int[]{2, 5, 6, 2}, 15, SoundEvents.ARMOR_EQUIP_DIAMOND, 2.0F, 0.1F, () -> Ingredient.of(Items.DIAMOND)),
    CHAINMOLDEN("chainmolden", 25, new int[]{2, 5, 6, 2}, 15, SoundEvents.ARMOR_EQUIP_DIAMOND, 2.0F, 0.1F, () -> Ingredient.of(Items.DIAMOND, Items.GOLD_INGOT)),
    CHAINMOND("chainmond", 25, new int[]{2, 5, 6, 2}, 15, SoundEvents.ARMOR_EQUIP_DIAMOND, 2.0F, 0.1F, () -> Ingredient.of(Items.DIAMOND, Items.GOLD_INGOT)),
    CHINMRON("chinmron", 25, new int[]{2, 5, 6, 2}, 15, SoundEvents.ARMOR_EQUIP_DIAMOND, 2.0F, 0.1F, () -> Ingredient.of(Items.DIAMOND, Items.GOLD_INGOT));

    private final String name;
    private final int durability;
    private final int[] damageReductionAmounts;
    private final int enchantability;
    private final SoundEvent equipSound;
    private final float toughness;
    private final float knockbackResistance;
    private final Lazy<Ingredient> repairMaterial;

    ModArmorMaterial(String name, int durability, int[] damageReductionAmounts, int enchantability, SoundEvent equipSound, float toughness, float knockbackResistance, Supplier<Ingredient> repairMaterial) {
        this.name = name;
        this.durability = durability;
        this.damageReductionAmounts = damageReductionAmounts;
        this.enchantability = enchantability;
        this.equipSound = equipSound;
        this.toughness = toughness;
        this.knockbackResistance = knockbackResistance;
        this.repairMaterial = Lazy.of(repairMaterial);
    }

    @Override
    public int getDurabilityForSlot(EquipmentSlotType slot) {
        return durability;
    }

    @Override
    public int getDefenseForSlot(EquipmentSlotType slot) {
        return damageReductionAmounts[slot.getIndex()];
    }

    @Override
    public int getEnchantmentValue() {
        return enchantability;
    }

    @Override
    public SoundEvent getEquipSound() {
        return equipSound;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return repairMaterial.get();
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public float getToughness() {
        return toughness;
    }

    @Override
    public float getKnockbackResistance() {
        return knockbackResistance;
    }
}
